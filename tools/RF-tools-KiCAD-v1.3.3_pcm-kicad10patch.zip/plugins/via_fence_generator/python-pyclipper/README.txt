Standalone vendored `pyclipper` for the Via Fence Generator
===========================================================

Why this exists
---------------
`via_fence_generator` needs the compiled `pyclipper` extension. KiCad ships
its own sandboxed Python, so installing pyclipper with pip does not persist
(and is awkward to ask every user to do). This folder bundles the binary so
the plugin works as soon as it is copied — no pip, no admin rights.

How it works
------------
`viafence_action.py` detects the running KiCad Python (version / OS / arch)
and prepends the matching folder below to sys.path before importing
pyclipper. Folder naming:

    py<MAJ><MIN>-<os>-<arch>/pyclipper/

      py39-mac-universal2   macOS (Intel + Apple Silicon), Python 3.9  -> KiCad 10.x
      py39-linux-x86_64     Linux x86_64, Python 3.9   (e.g. Ubuntu 20.04)
      py310-linux-x86_64    Linux x86_64, Python 3.10  (e.g. Ubuntu 22.04)
      py311-linux-x86_64    Linux x86_64, Python 3.11  (e.g. Debian 12, Flatpak)
      py312-linux-x86_64    Linux x86_64, Python 3.12  (e.g. Ubuntu 24.04, Fedora)
      py313-linux-x86_64    Linux x86_64, Python 3.13  (e.g. Arch, Fedora 40+)
      py39-win-amd64        Windows x64, Python 3.9    (see Windows note)

Coverage: macOS and Linux x86_64 (KiCad 10.x) are bundled and tested.

Adding an uncovered setup (e.g. Linux ARM, a different Python)
--------------------------------------------------------------
1. Find KiCad's Python version: Tools > Scripting Console, then
       import sys, platform; print(sys.version, platform.machine())
2. Download the matching wheel (no install needed):
       pip download pyclipper --only-binary=:all: \
         --implementation cp --abi cp<MAJMIN> \
         --python-version <MAJ.MIN> --platform <tag>
3. Unzip the .whl and copy ONLY its `pyclipper/` package into a new
   folder named `py<MAJ><MIN>-<os>-<arch>/` here.

Windows note
------------
`py39-win-amd64` uses a standard CPython (MSVC) wheel. KiCad's Windows
build uses an MSYS2/mingw Python whose extension ABI can differ, so this
binary may fail to import there. If it does, the simplest fix on Windows
is to run, in KiCad's Scripting Console:  `pip install pyclipper`.

Source: pyclipper 1.3.0.post6 / 1.4.0 wheels from PyPI (MIT/BSD-licensed,
see each pyclipper/ package). Only the `pyclipper/` package is vendored
(no dist-info, no other platforms) to keep the plugin lean.
